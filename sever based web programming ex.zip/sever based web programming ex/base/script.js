// Example cart array containing items with prices
let cart = [];

// Function to calculate the total of purchases in the cart
function calculateTotal() {
  let total = 0;

  for (let item of cart) {
    total += item.price * item.quantity;
  }

  return total;
}

// Function to add an item to the cart
function addToCart(item) {
  cart.push(item);
  console.log('Item added to cart:', item);
}

// Example product object
const product = {
  name: 'Product 1',
  price: 19.99,
  quantity: 1
};

// Example "Add to Cart" button click event handler
function handleAddToCart() {
  addToCart(product);
  const cartTotal = calculateTotal();
  console.log('Cart Total:', cartTotal);
}

// Attach the click event handler to the "Add to Cart" button
const addToCartButton = document.getElementById('add-to-cart-button');
addToCartButton.addEventListener('click', handleAddToCart);
